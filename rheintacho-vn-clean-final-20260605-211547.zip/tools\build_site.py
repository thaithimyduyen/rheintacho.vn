#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import html
import json
import re
import shutil
import unicodedata
from datetime import date
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
DATA_DIR = ASSETS / "data"
IMAGES_DIR = ASSETS / "images"
DOCUMENTS_DIR = ROOT / "documents"

DOMAIN = "https://rheintacho.com.vn"
BRAND = "Rheintacho Việt Nam"
EMAIL = "sales@rheintacho.vn"
PHONE = "+84 938 888 958"
PHONE_TEL = "+84938888958"
LEGAL_NAME = "Fast Group Co., Ltd"
DISTRIBUTOR = "Fast Group Engineering"
TAX_CODE = "0315555189"
APP_DESCRIPTION = (
    "Đo tốc độ quay (RPM) là yêu cầu quan trọng trong sản xuất, năng lượng và cơ khí. "
    "Các thiết bị Rheintacho giúp giám sát tốc độ chính xác, giảm thời gian dừng máy "
    "và tối ưu hiệu suất vận hành."
)

GROUP_META = {
    "rotational_speed_sensors": {
        "name": "Cảm biến tốc độ quay",
        "slug": "cam-bien-toc-do-quay",
        "description": "Cảm biến Hall, Differential Hall và GMR dùng để đo tốc độ quay trong môi trường công nghiệp nặng.",
    },
    "stationary_stroboscopes": {
        "name": "Đèn nháy cố định",
        "slug": "den-nhay-co-dinh",
        "description": "Thiết bị quan sát và đo tốc độ không tiếp xúc cho dây chuyền sản xuất, máy in, quạt, trục và thiết bị quay.",
    },
    "portable_stroboscopes": {
        "name": "Đèn nháy cầm tay",
        "slug": "den-nhay-cam-tay",
        "description": "Dòng đèn nháy di động phục vụ bảo trì, kiểm tra tại hiện trường và phân tích chuyển động nhanh.",
    },
    "digital_hand_tachometers": {
        "name": "Máy đo tốc độ cầm tay",
        "slug": "may-do-toc-do-cam-tay",
        "description": "Thiết bị đo tốc độ quay cầm tay cho kỹ thuật viên bảo trì, vận hành và kiểm tra máy móc.",
    },
    "others_products": {
        "name": "Bộ giám sát tốc độ",
        "slug": "bo-giam-sat-toc-do",
        "description": "Bộ giám sát, cảnh báo và bảo vệ tốc độ quay cho hệ thống công nghiệp.",
    },
    "accessories": {
        "name": "Phụ kiện và linh kiện",
        "slug": "phu-kien",
        "description": "Cáp, adapter, pin, bánh xe đo, đầu đo, phụ kiện gá lắp và linh kiện thay thế Rheintacho.",
    },
}

APPLICATION_IMAGES = {
    "do-toc-do-dong-co": "csm_Teaser_Anwendungen_Grossmotoren_270x160px_53fc9eeb4c.jpg",
    "giam-sat-toc-do-turbine": "csm_Teaser_Anwendungen_Windenergie_270x160px_359bc18acc.jpg",
    "giam-sat-toc-do-may-bom": "csm_Teaser_Anwendungen_Mobilhydraulik_Bagger_270x160px_ba79cd5e53.jpg",
    "do-toc-do-bang-tai": "csm_Teaser_Anwendungen_Flurfoerderzeuge_270x160px_b70f508d66.jpg",
    "giam-sat-thiet-bi-quay": "Produktuebersicht_2018_870x386px_72dpi.jpg",
    "giam-sat-toc-do-may-phat-dien": "csm_Teaser_Anwendungen_Grossmotoren_270x160px_53fc9eeb4c.jpg",
    "giam-sat-toc-do-hop-so": "csm_Teaser_Anwendungen_Mobilhydraulik_Bagger_270x160px_ba79cd5e53.jpg",
    "do-toc-do-quat-cong-nghiep": "csm_Textilbranche_270x160px_a3e6e30891.jpg",
    "do-toc-do-may-cnc": "sensor.jpg",
    "do-toc-do-nganh-thep": "ROLUX_Zahnrad_870x386px.jpg",
    "giam-sat-toc-do-nha-may-xi-mang": "csm_Teaser_Anwendungen_Flurfoerderzeuge_270x160px_b70f508d66.jpg",
    "cach-do-toc-do-rpm": "banner_tachometer.jpg",
    "cach-chon-thiet-bi-do-toc-do": "Produktuebersicht_2018_870x386px_72dpi.jpg",
}

WEBP_AVAILABLE = {p.name for p in IMAGES_DIR.glob("*.webp")}


def esc(value):
    return html.escape(str(value or ""), quote=True)


def load_json(path):
    def keep_duplicates(pairs):
        data = {}
        for key, value in pairs:
            if key not in data:
                data[key] = value
                continue
            suffix = 2
            while f"{key}__dup{suffix}" in data:
                suffix += 1
            data[f"{key}__dup{suffix}"] = value
        return data

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=keep_duplicates)


def vi_value(value, fallback=""):
    if isinstance(value, dict) and "vi" in value:
        return value.get("vi") or fallback
    return value if value not in (None, "") else fallback


def ensure_list(value):
    value = vi_value(value, [])
    if isinstance(value, list):
        return value
    if value in (None, ""):
        return []
    return [value]


def slugify(text):
    text = str(text or "")
    text = unicodedata.normalize("NFD", text)
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    text = text.replace("đ", "d").replace("Đ", "d")
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()
    return re.sub(r"-+", "-", text) or "trang"


def prefer_webp(filename):
    if not filename:
        return ""
    name = Path(str(filename)).name
    match = re.match(r"^(.*)\.(jpg|jpeg|png)$", name, re.IGNORECASE)
    if not match:
        return name
    candidate = f"{match.group(1)}.webp"
    return candidate if candidate in WEBP_AVAILABLE else name


def image_url(filename):
    name = prefer_webp(filename)
    return f"/assets/images/{name}" if name else "/assets/images/main_logo_icon.webp"


def strip_html_shell(fragment):
    text = str(fragment or "")
    text = re.sub(r"<!doctype[^>]*>", "", text, flags=re.I)
    text = re.sub(r"<script\b[^>]*>.*?</script>", "", text, flags=re.I | re.S)
    text = re.sub(r"<style\b[^>]*>.*?</style>", "", text, flags=re.I | re.S)
    body = re.search(r"<body\b[^>]*>(.*?)</body>", text, flags=re.I | re.S)
    if body:
        text = body.group(1)
    text = re.sub(r"</?(html|head|body)\b[^>]*>", "", text, flags=re.I)
    text = re.sub(r"<meta\b[^>]*>", "", text, flags=re.I)
    text = re.sub(r"<title\b[^>]*>.*?</title>", "", text, flags=re.I | re.S)
    text = re.sub(r"<h1\b[^>]*>.*?</h1>", "", text, count=1, flags=re.I | re.S)
    text = re.sub(r"\s(?:class|id|style|title)=(\"[^\"]*\"|'[^']*')", "", text, flags=re.I)
    text = re.sub(r"\shref=(\"|')/en/[^\"']*(\"|')", ' href="/products/"', text, flags=re.I)
    text = re.sub(r"\schế độ pro\b", " chế độ nâng cao", text, flags=re.I)
    text = re.sub(r"\bpro mode\b", "chế độ nâng cao", text, flags=re.I)
    return vi_cleanup_text(text.strip())


def text_from_html(fragment, limit=165):
    text = re.sub(r"<[^>]+>", " ", str(fragment or ""))
    text = html.unescape(re.sub(r"\s+", " ", text)).strip()
    text = vi_cleanup_text(text)
    if len(text) <= limit:
        return text
    cut = text[: limit + 1].rsplit(" ", 1)[0]
    return cut.rstrip(" ,.;:-")


def vi_cleanup_text(text):
    replacements = {
        "downtime": "thời gian dừng máy",
        "stroboscope": "đèn nháy đo tốc độ",
        "tachometer": "máy đo tốc độ",
        "analog": "tương tự",
        "digital": "kỹ thuật số",
        "photoelectric": "quang điện",
        "server": "máy chủ",
        "spindle": "trục chính",
    }
    result = str(text or "")
    for src, dst in replacements.items():
        result = re.sub(rf"\b{re.escape(src)}\b", dst, result, flags=re.I)
    return result


PART_RE = re.compile(r"\b([A-Z]\d{4}\.\d{2,4}[A-Z]?(?:-\d+)?)\b")


def part_number(fragment):
    match = PART_RE.search(str(fragment or ""))
    return match.group(1) if match else ""


def clean_product_name(name):
    text = str(name or "").strip()
    text = re.sub(r"\bAdapter\b", "Bộ chuyển đổi", text, flags=re.I)
    text = re.sub(r"\bBumper cạnh\b", "Đệm bảo vệ cạnh", text, flags=re.I)
    text = re.sub(r"\bỐng flash\b", "Ống đèn nháy", text, flags=re.I)
    return text


def variant_descriptor(product_key):
    key = str(product_key or "").lower()
    parts = []
    if "angled" in key:
        parts.append("ra góc 90 độ")
    elif "straight" in key:
        parts.append("ra thẳng")

    length = re.search(r"(\d+)m-cable", key)
    if length:
        parts.append(f"cáp {length.group(1)} m")

    if "7000-led-12000-led" in key:
        parts.append("cho RT STROBE 7000/12000 LED")
    elif "3000-led-5000-led" in key:
        parts.append("cho RT STROBE 3000/5000 LED")

    return ", ".join(parts)


def normalize_products(raw):
    groups = []
    for group_key, group_raw in raw.items():
        if not isinstance(group_raw, dict):
            continue

        meta = GROUP_META.get(group_key, {})
        group_slug = meta.get("slug") or vi_value(group_raw.get("slug"), slugify(group_key))
        group_name = meta.get("name") or group_raw.get("name") or group_slug.replace("-", " ").title()
        group_desc = meta.get("description") or vi_value(group_raw.get("description"), "")

        group = {
            "key": group_key,
            "name": group_name,
            "slug": group_slug,
            "description": text_from_html(group_desc, 240),
            "main_image": prefer_webp(group_raw.get("main_image") or "Produktuebersicht_2018_870x386px_72dpi.jpg"),
            "products": [],
        }

        if isinstance(group_raw.get("products"), list):
            product_sources = [(p.get("key", p.get("slug", "")), p) for p in group_raw["products"]]
        else:
            product_sources = [
                (key, value)
                for key, value in group_raw.items()
                if isinstance(value, dict) and "name" in value
            ]

        seen_slugs = {}
        for product_key, product_raw in product_sources:
            name = clean_product_name(vi_value(product_raw.get("name"), "Sản phẩm Rheintacho"))
            descriptor = variant_descriptor(product_key)
            if descriptor and descriptor not in name:
                name = f"{name} ({descriptor})"
            slug = slugify(name)
            if slug in seen_slugs:
                seen_slugs[slug] += 1
                slug = f"{slug}-bien-the-{seen_slugs[slug]}"
            else:
                seen_slugs[slug] = 1

            description = strip_html_shell(vi_value(product_raw.get("description"), ""))
            scope = strip_html_shell(vi_value(product_raw.get("scope_of_delivery"), ""))
            short = vi_value(product_raw.get("short_description"), text_from_html(description, 150))
            specs = vi_value(product_raw.get("technical_data"), {}) or {}

            product = {
                "key": str(product_key),
                "name": name,
                "slug": slug,
                "category": vi_value(product_raw.get("category"), group_name),
                "short_description": text_from_html(short, 180),
                "description": description,
                "features": [str(item).strip() for item in ensure_list(product_raw.get("features")) if str(item).strip()],
                "applications": [str(item).strip() for item in ensure_list(product_raw.get("applications")) if str(item).strip()],
                "scope_of_delivery": scope,
                "technical_data": specs if isinstance(specs, dict) else {},
                "images": [prefer_webp(Path(str(img)).name) for img in product_raw.get("images", []) if str(img).strip()],
                "docs": [Path(str(doc)).name for doc in product_raw.get("docs", []) if str(doc).strip()],
                "part_number": part_number(description),
            }
            group["products"].append(product)

        groups.append(group)

    groups.sort(key=lambda item: list(GROUP_META).index(item["key"]) if item["key"] in GROUP_META else 99)
    return groups


def normalize_applications(raw):
    apps = []
    for item in raw.get("applications", []):
        slug = slugify(vi_value(item.get("slug"), item.get("name", "")))
        apps.append(
            {
                "slug": slug,
                "name": vi_value(item.get("name"), "Ứng dụng Rheintacho"),
                "short_description": text_from_html(vi_value(item.get("short_description"), ""), 190),
                "content": strip_html_shell(vi_value(item.get("content"), "")),
                "image": prefer_webp(APPLICATION_IMAGES.get(slug, "Produktuebersicht_2018_870x386px_72dpi.jpg")),
            }
        )
    return {
        "title": vi_value(raw.get("title"), "Ứng dụng đo tốc độ trong công nghiệp"),
        "description": APP_DESCRIPTION,
        "applications": apps,
    }


def write_clean_data(groups, applications):
    products_out = {
        group["key"]: {
            "name": group["name"],
            "slug": group["slug"],
            "description": group["description"],
            "main_image": group["main_image"],
            "products": group["products"],
        }
        for group in groups
    }
    (DATA_DIR / "products.json").write_text(
        json.dumps(products_out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    (DATA_DIR / "applications.json").write_text(
        json.dumps(applications, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def write_file(relative_path, content):
    path = ROOT / relative_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.strip() + "\n", encoding="utf-8")


def absolute(path):
    return f"{DOMAIN}{path}"


def nav_item(label, href, active):
    cls = " active" if active == href or (href != "/" and active.startswith(href)) else ""
    return f'<a class="nav-link{cls}" href="{href}">{label}</a>'


def render_header(active="/"):
    return f"""
<header class="site-header">
  <div class="topbar">
    <div class="container topbar-inner">
      <span>Nhà phân phối ủy quyền Rheintacho tại Việt Nam</span>
      <div class="topbar-links">
        <a href="mailto:{EMAIL}">{EMAIL}</a>
        <a href="tel:{PHONE_TEL}">{PHONE}</a>
      </div>
    </div>
  </div>
  <nav class="navbar" aria-label="Điều hướng chính">
    <div class="container nav-inner">
      <a class="brand" href="/">
        <img src="/assets/images/main_logo_icon.webp" alt="{BRAND}" width="44" height="44">
        <span><strong>RHEINTACHO</strong><small>Việt Nam</small></span>
      </a>
      <button class="menu-toggle" type="button" aria-label="Mở menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
      <div class="nav-menu">
        {nav_item("Trang chủ", "/", active)}
        {nav_item("Sản phẩm", "/products/", active)}
        {nav_item("Ứng dụng", "/pages/ung-dung.html", active)}
        {nav_item("Giới thiệu", "/pages/gioi-thieu.html", active)}
        {nav_item("Liên hệ", "/pages/lien-he.html", active)}
        <a class="quote-link" href="/pages/lien-he.html">Báo giá</a>
      </div>
    </div>
  </nav>
</header>"""


def render_footer(groups, apps):
    product_links = "".join(
        f'<li><a href="/products/{group["slug"]}/">{esc(group["name"])}</a></li>'
        for group in groups
    )
    app_links = "".join(
        f'<li><a href="/pages/ung-dung/{app["slug"]}/">{esc(app["name"])}</a></li>'
        for app in apps["applications"][:5]
    )
    return f"""
<footer class="site-footer">
  <div class="footer-cta">
    <div class="container footer-cta-inner">
      <div>
        <span>{DISTRIBUTOR}</span>
        <h2>Cần chọn đúng model Rheintacho cho ứng dụng của bạn?</h2>
      </div>
      <a class="btn btn-light" href="/pages/lien-he.html">Gửi yêu cầu tư vấn</a>
    </div>
  </div>
  <div class="container footer-main">
    <div class="footer-grid">
      <div>
        <div class="footer-brand">
          <img src="/assets/images/main_logo_icon.webp" alt="{BRAND}" width="42" height="42">
          <span><strong>RHEINTACHO</strong><small>Việt Nam</small></span>
        </div>
        <p>Giải pháp đo và giám sát tốc độ Rheintacho chính hãng, được phân phối tại Việt Nam bởi {DISTRIBUTOR}.</p>
        <p class="legal">{LEGAL_NAME}<br>MST: {TAX_CODE}</p>
      </div>
      <div>
        <h3>Sản phẩm</h3>
        <ul>{product_links}</ul>
      </div>
      <div>
        <h3>Ứng dụng</h3>
        <ul>{app_links}</ul>
      </div>
      <div>
        <h3>Liên hệ</h3>
        <ul class="contact-list">
          <li><a href="mailto:{EMAIL}">{EMAIL}</a></li>
          <li><a href="tel:{PHONE_TEL}">{PHONE}</a></li>
          <li>Fast Group Engineering</li>
          <li>Phân phối Rheintacho tại Việt Nam</li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© {date.today().year} {BRAND}</span>
      <span>Website: rheintacho.com.vn</span>
    </div>
  </div>
</footer>
<a class="floating-contact" href="https://zalo.me/84938888958" target="_blank" rel="noopener noreferrer" aria-label="Chat Zalo">Zalo</a>"""


def html_page(title, description, path, body, groups, apps, image="/assets/images/main_logo_icon.webp", active="/", index=True):
    robots = "index, follow" if index else "noindex, follow"
    return f"""<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(title)}</title>
  <meta name="description" content="{esc(description)}">
  <meta name="robots" content="{robots}">
  <link rel="canonical" href="{absolute(path)}">
  <meta property="og:title" content="{esc(title)}">
  <meta property="og:description" content="{esc(description)}">
  <meta property="og:url" content="{absolute(path)}">
  <meta property="og:image" content="{absolute(image)}">
  <meta property="og:type" content="website">
  <meta property="og:locale" content="vi_VN">
  <link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png">
  <link rel="manifest" href="/assets/images/site.webmanifest">
  <link rel="stylesheet" href="/assets/css/site.css">
</head>
<body>
{render_header(active)}
{body}
{render_footer(groups, apps)}
<script src="/assets/js/site.js"></script>
</body>
</html>"""


def breadcrumb(items):
    parts = []
    for index, (label, href) in enumerate(items):
        if href:
            parts.append(f'<a href="{href}">{esc(label)}</a>')
        else:
            parts.append(f'<span>{esc(label)}</span>')
        if index < len(items) - 1:
            parts.append('<i>/</i>')
    return f'<nav class="breadcrumb" aria-label="Đường dẫn">{"".join(parts)}</nav>'


def group_card(group):
    return f"""
<a class="category-card" href="/products/{group['slug']}/">
  <img src="{image_url(group['main_image'])}" alt="{esc(group['name'])}" loading="lazy">
  <div>
    <strong>{esc(group['name'])}</strong>
    <span>{len(group['products'])} dòng sản phẩm</span>
    <p>{esc(group['description'])}</p>
  </div>
</a>"""


def product_card(product, group):
    image = image_url(product["images"][0] if product["images"] else group["main_image"])
    return f"""
<a class="product-card" href="/products/{group['slug']}/{product['slug']}/" data-search="{esc((product['name'] + ' ' + product.get('part_number', '') + ' ' + product.get('category', '')).lower())}">
  <div class="product-image"><img src="{image}" alt="{esc(product['name'])}" loading="lazy"></div>
  <div class="product-body">
    <span>{esc(product.get('category') or group['name'])}</span>
    <h3>{esc(product['name'])}</h3>
    <p>{esc(product.get('short_description') or text_from_html(product.get('description'), 120))}</p>
  </div>
</a>"""


def section_intro(kicker, title, text):
    return f"""
<div class="section-intro">
  <span>{esc(kicker)}</span>
  <h2>{esc(title)}</h2>
  <p>{esc(text)}</p>
</div>"""


def render_home(groups, apps):
    category_cards = "".join(group_card(group) for group in groups)
    featured = "".join(product_card(product, group) for group in groups[:4] for product in group["products"][:1])
    app_cards = "".join(app_card(app) for app in apps["applications"][:4])
    body = f"""
<main>
  <section class="hero">
    <div class="container hero-grid">
      <div class="hero-copy">
        <span class="eyebrow">Rheintacho Việt Nam</span>
        <h1>Công nghệ đo tốc độ chính xác từ Đức</h1>
        <p>{DISTRIBUTOR} phân phối thiết bị Rheintacho chính hãng tại Việt Nam: cảm biến tốc độ quay, đèn nháy đo tốc độ, máy đo tốc độ cầm tay và bộ giám sát tốc độ cho công nghiệp.</p>
        <div class="hero-actions">
          <a class="btn btn-primary" href="/products/">Xem sản phẩm</a>
          <a class="btn btn-secondary" href="/pages/lien-he.html">Yêu cầu báo giá</a>
        </div>
      </div>
      <div class="hero-media">
        <img src="{image_url('Produktuebersicht_2018_870x386px_72dpi.jpg')}" alt="Sản phẩm Rheintacho chính hãng tại Việt Nam">
      </div>
    </div>
  </section>

  <section class="trust-strip">
    <div class="container trust-grid">
      <div><strong>Chính hãng</strong><span>Nguồn gốc Rheintacho Đức</span></div>
      <div><strong>Tư vấn kỹ thuật</strong><span>Chọn model theo ứng dụng</span></div>
      <div><strong>Hỗ trợ doanh nghiệp</strong><span>VAT, chứng từ và báo giá</span></div>
      <div><strong>Thị trường Việt Nam</strong><span>Fast Group Engineering</span></div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      {section_intro("Danh mục", "Sản phẩm Rheintacho", "Cấu trúc sản phẩm được gom lại theo nhóm rõ ràng để dễ tra cứu, báo giá và phát triển thêm nội dung kỹ thuật.")}
      <div class="category-grid">{category_cards}</div>
    </div>
  </section>

  <section class="section muted">
    <div class="container">
      {section_intro("Nổi bật", "Một số dòng sản phẩm tiêu biểu", "Các sản phẩm đại diện cho nhóm cảm biến, đèn nháy, máy đo tốc độ và giải pháp giám sát tốc độ.")}
      <div class="product-grid">{featured}</div>
    </div>
  </section>

  <section class="section">
    <div class="container">
      {section_intro("Ứng dụng", "Đo tốc độ trong nhà máy và hệ thống công nghiệp", "Rheintacho được sử dụng trong bảo trì, vận hành, kiểm tra tốc độ quay và giám sát thiết bị.")}
      <div class="app-grid">{app_cards}</div>
    </div>
  </section>
</main>"""
    return html_page(
        "Rheintacho Việt Nam | Cảm biến tốc độ, đèn nháy và máy đo tốc độ",
        "Rheintacho Việt Nam phân phối cảm biến tốc độ quay, đèn nháy đo tốc độ, máy đo tốc độ cầm tay và bộ giám sát tốc độ chính hãng.",
        "/",
        body,
        groups,
        apps,
        image=image_url("Produktuebersicht_2018_870x386px_72dpi.jpg"),
        active="/",
    )


def app_card(app):
    return f"""
<a class="app-card" href="/pages/ung-dung/{app['slug']}/">
  <img src="{image_url(app['image'])}" alt="{esc(app['name'])}" loading="lazy">
  <div>
    <strong>{esc(app['name'])}</strong>
    <p>{esc(app['short_description'])}</p>
  </div>
</a>"""


def render_products_index(groups, apps):
    category_cards = "".join(group_card(group) for group in groups)
    all_cards = "".join(product_card(product, group) for group in groups for product in group["products"])
    total = sum(len(group["products"]) for group in groups)
    body = f"""
<main>
  <section class="page-hero">
    <div class="container">
      {breadcrumb([("Trang chủ", "/"), ("Sản phẩm", None)])}
      <h1>Sản phẩm Rheintacho</h1>
      <p>{total} sản phẩm được sắp xếp lại theo nhóm tiếng Việt, không còn lớp menu song ngữ cũ.</p>
    </div>
  </section>
  <section class="section">
    <div class="container">
      {section_intro("Danh mục", "Nhóm sản phẩm", "Chọn nhóm sản phẩm để xem danh sách model phù hợp.")}
      <div class="category-grid">{category_cards}</div>
    </div>
  </section>
  <section class="section muted">
    <div class="container">
      <div class="search-bar">
        <label for="productSearch">Tìm sản phẩm</label>
        <input id="productSearch" type="search" placeholder="Nhập tên sản phẩm, mã hoặc nhóm sản phẩm">
      </div>
      <div class="product-grid" id="productGrid">{all_cards}</div>
      <p class="empty-state" id="emptyProducts">Không tìm thấy sản phẩm phù hợp.</p>
    </div>
  </section>
</main>"""
    return html_page(
        "Sản phẩm Rheintacho Việt Nam",
        "Danh mục sản phẩm Rheintacho chính hãng tại Việt Nam: cảm biến tốc độ quay, đèn nháy, máy đo tốc độ cầm tay, phụ kiện và bộ giám sát tốc độ.",
        "/products/",
        body,
        groups,
        apps,
        active="/products/",
    )


def render_group_page(group, groups, apps):
    cards = "".join(product_card(product, group) for product in group["products"])
    body = f"""
<main>
  <section class="page-hero">
    <div class="container">
      {breadcrumb([("Trang chủ", "/"), ("Sản phẩm", "/products/"), (group["name"], None)])}
      <h1>{esc(group["name"])}</h1>
      <p>{esc(group["description"])}</p>
    </div>
  </section>
  <section class="section muted">
    <div class="container">
      <div class="product-grid">{cards}</div>
    </div>
  </section>
</main>"""
    return html_page(
        f"{group['name']} | Rheintacho Việt Nam",
        group["description"],
        f"/products/{group['slug']}/",
        body,
        groups,
        apps,
        image=image_url(group["main_image"]),
        active="/products/",
    )


def render_specs(product):
    specs = product.get("technical_data") or {}
    if not specs:
        return ""
    rows = "".join(
        f"<tr><th>{esc(key)}</th><td>{esc(value)}</td></tr>"
        for key, value in specs.items()
        if str(value).strip()
    )
    return f'<section class="detail-block"><h2>Thông số kỹ thuật</h2><table class="spec-table">{rows}</table></section>' if rows else ""


def render_list_block(title, items):
    clean = [str(item).strip() for item in items or [] if str(item).strip()]
    if not clean:
        return ""
    body = "".join(f"<li>{esc(item)}</li>" for item in clean)
    return f'<section class="detail-block"><h2>{esc(title)}</h2><ul class="check-list">{body}</ul></section>'


def render_docs(product):
    links = []
    for doc in product.get("docs", []):
        candidate = DOCUMENTS_DIR / Path(doc).name
        if candidate.exists():
            label = Path(doc).stem.replace("_", " ").replace("-", " ")
            links.append(f'<a class="doc-link" href="/documents/{esc(Path(doc).name)}">{esc(label)} <span>PDF</span></a>')
    if not links:
        return ""
    return f'<section class="detail-block"><h2>Tài liệu kỹ thuật</h2><div class="doc-list">{"".join(links)}</div></section>'


def render_product_page(product, group, groups, apps):
    image = image_url(product["images"][0] if product["images"] else group["main_image"])
    thumbs = "".join(
        f'<button type="button" class="thumb" data-image="{image_url(img)}"><img src="{image_url(img)}" alt="{esc(product["name"])}" loading="lazy"></button>'
        for img in product.get("images", [])[:8]
    )
    model = product.get("part_number") or product.get("category") or group["name"]
    scope = product.get("scope_of_delivery", "")
    scope_block = f'<section class="detail-block"><h2>Phạm vi giao hàng</h2><div class="article-fragment">{scope}</div></section>' if scope else ""
    body = f"""
<main>
  <section class="product-detail">
    <div class="container">
      {breadcrumb([("Trang chủ", "/"), ("Sản phẩm", "/products/"), (group["name"], f"/products/{group['slug']}/"), (product["name"], None)])}
      <div class="detail-grid">
        <div class="gallery">
          <div class="main-image"><img id="mainProductImage" src="{image}" alt="{esc(product['name'])}"></div>
          <div class="thumbs">{thumbs}</div>
        </div>
        <div class="detail-info">
          <span class="model-line">{esc(model)}</span>
          <h1>{esc(product['name'])}</h1>
          <div class="article-fragment">{product.get('description') or '<p>Liên hệ Fast Group Engineering để nhận thông tin kỹ thuật chi tiết cho sản phẩm này.</p>'}</div>
          <div class="detail-actions">
            <a class="btn btn-primary" href="/pages/lien-he.html">Yêu cầu báo giá</a>
            <a class="btn btn-secondary" href="tel:{PHONE_TEL}">Gọi tư vấn</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="section">
    <div class="container detail-sections">
      {render_list_block("Tính năng nổi bật", product.get("features"))}
      {render_list_block("Ứng dụng tiêu biểu", product.get("applications"))}
      {render_specs(product)}
      {scope_block}
      {render_docs(product)}
    </div>
  </section>
</main>"""
    desc = product.get("short_description") or text_from_html(product.get("description"), 155)
    return html_page(
        f"{product['name']} | {BRAND}",
        desc,
        f"/products/{group['slug']}/{product['slug']}/",
        body,
        groups,
        apps,
        image=image,
        active="/products/",
    )


def render_about(groups, apps):
    body = f"""
<main>
  <section class="page-hero">
    <div class="container">
      {breadcrumb([("Trang chủ", "/"), ("Giới thiệu", None)])}
      <h1>Rheintacho Việt Nam</h1>
      <p>{DISTRIBUTOR} là đơn vị phân phối sản phẩm Rheintacho tại Việt Nam, tập trung vào giải pháp đo và giám sát tốc độ cho công nghiệp.</p>
    </div>
  </section>
  <section class="section">
    <div class="container split-layout">
      <div>
        <span class="eyebrow">Thương hiệu</span>
        <h2>Thiết bị đo tốc độ Rheintacho cho môi trường công nghiệp</h2>
        <p>Rheintacho phát triển các dòng cảm biến tốc độ, đèn nháy đo tốc độ, máy đo tốc độ cầm tay và bộ giám sát tốc độ. Tại Việt Nam, Fast Group Engineering hỗ trợ tư vấn model, báo giá, chứng từ và định hướng kỹ thuật theo ứng dụng thực tế.</p>
        <p>Website này được làm lại theo nền tảng tiếng Việt gọn hơn để thuận tiện quản trị, phát triển danh mục sản phẩm, nội dung kỹ thuật và SEO trong các giai đoạn tiếp theo.</p>
      </div>
      <aside class="info-panel">
        <h3>Thông tin doanh nghiệp</h3>
        <dl>
          <dt>Thương hiệu hiển thị</dt><dd>{BRAND}</dd>
          <dt>Website</dt><dd>rheintacho.com.vn</dd>
          <dt>Email</dt><dd><a href="mailto:{EMAIL}">{EMAIL}</a></dd>
          <dt>Đơn vị phân phối</dt><dd>{DISTRIBUTOR}</dd>
          <dt>Công ty pháp lý</dt><dd>{LEGAL_NAME}</dd>
          <dt>MST</dt><dd>{TAX_CODE}</dd>
        </dl>
      </aside>
    </div>
  </section>
</main>"""
    return html_page(
        "Giới thiệu Rheintacho Việt Nam",
        "Thông tin Rheintacho Việt Nam, Fast Group Engineering và Fast Group Co., Ltd.",
        "/pages/gioi-thieu.html",
        body,
        groups,
        apps,
        active="/pages/gioi-thieu.html",
    )


def render_contact(groups, apps):
    body = f"""
<main>
  <section class="page-hero">
    <div class="container">
      {breadcrumb([("Trang chủ", "/"), ("Liên hệ", None)])}
      <h1>Liên hệ và yêu cầu báo giá</h1>
      <p>Gửi nhu cầu kỹ thuật, mã sản phẩm hoặc thông tin ứng dụng để Fast Group Engineering tư vấn model Rheintacho phù hợp.</p>
    </div>
  </section>
  <section class="section">
    <div class="container contact-layout">
      <div class="contact-cards">
        <a class="contact-card" href="mailto:{EMAIL}"><strong>Email</strong><span>{EMAIL}</span></a>
        <a class="contact-card" href="tel:{PHONE_TEL}"><strong>Điện thoại</strong><span>{PHONE}</span></a>
        <a class="contact-card" href="https://zalo.me/84938888958" target="_blank" rel="noopener noreferrer"><strong>Zalo</strong><span>Chat nhanh với kỹ thuật</span></a>
        <div class="contact-card"><strong>Đơn vị phân phối</strong><span>{DISTRIBUTOR}</span></div>
      </div>
      <form class="contact-form" action="mailto:{EMAIL}" method="post" enctype="text/plain">
        <h2>Gửi yêu cầu qua email</h2>
        <label>Họ và tên<input name="Ho va ten" required></label>
        <label>Công ty<input name="Cong ty"></label>
        <label>Số điện thoại<input name="So dien thoai" required></label>
        <label>Sản phẩm hoặc model quan tâm<input name="San pham"></label>
        <label>Nội dung yêu cầu<textarea name="Noi dung" rows="5" required></textarea></label>
        <button class="btn btn-primary" type="submit">Gửi yêu cầu</button>
      </form>
    </div>
  </section>
</main>"""
    return html_page(
        "Liên hệ Rheintacho Việt Nam",
        f"Liên hệ {DISTRIBUTOR} để tư vấn và báo giá sản phẩm Rheintacho chính hãng tại Việt Nam.",
        "/pages/lien-he.html",
        body,
        groups,
        apps,
        active="/pages/lien-he.html",
    )


def render_app_index(groups, apps):
    cards = "".join(app_card(app) for app in apps["applications"])
    body = f"""
<main>
  <section class="page-hero">
    <div class="container">
      {breadcrumb([("Trang chủ", "/"), ("Ứng dụng", None)])}
      <h1>{esc(apps["title"])}</h1>
      <p>{esc(apps["description"])}</p>
    </div>
  </section>
  <section class="section muted">
    <div class="container">
      <div class="app-grid app-grid-wide">{cards}</div>
    </div>
  </section>
</main>"""
    return html_page(
        "Ứng dụng đo tốc độ trong công nghiệp",
        apps["description"],
        "/pages/ung-dung.html",
        body,
        groups,
        apps,
        active="/pages/ung-dung.html",
    )


def render_app_detail(app, groups, apps):
    body = f"""
<main>
  <section class="page-hero">
    <div class="container">
      {breadcrumb([("Trang chủ", "/"), ("Ứng dụng", "/pages/ung-dung.html"), (app["name"], None)])}
      <h1>{esc(app["name"])}</h1>
      <p>{esc(app["short_description"])}</p>
    </div>
  </section>
  <section class="section">
    <div class="container article-layout">
      <article class="article-content">{app["content"]}</article>
      <aside class="article-aside">
        <img src="{image_url(app["image"])}" alt="{esc(app["name"])}" loading="lazy">
        <h2>Cần tư vấn ứng dụng?</h2>
        <p>Gửi thông tin máy móc, tốc độ quay, môi trường lắp đặt và yêu cầu tín hiệu để được đề xuất thiết bị phù hợp.</p>
        <a class="btn btn-primary" href="/pages/lien-he.html">Liên hệ tư vấn</a>
      </aside>
    </div>
  </section>
</main>"""
    return html_page(
        f"{app['name']} | Rheintacho Việt Nam",
        app["short_description"],
        f"/pages/ung-dung/{app['slug']}/",
        body,
        groups,
        apps,
        image=image_url(app["image"]),
        active="/pages/ung-dung.html",
    )


def render_404(groups, apps):
    body = """
<main>
  <section class="page-hero">
    <div class="container">
      <h1>Không tìm thấy trang</h1>
      <p>Trang bạn truy cập không còn tồn tại trong cấu trúc website mới.</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="/">Về trang chủ</a>
        <a class="btn btn-secondary" href="/products/">Xem sản phẩm</a>
      </div>
    </div>
  </section>
</main>"""
    return html_page(
        "Không tìm thấy trang | Rheintacho Việt Nam",
        "Trang không tìm thấy trên Rheintacho Việt Nam.",
        "/404.html",
        body,
        groups,
        apps,
        active="/",
        index=False,
    )


def build_sitemap(urls):
    today = date.today().isoformat()
    entries = []
    for path, priority in urls:
        entries.append(
            f"  <url><loc>{absolute(path)}</loc><lastmod>{today}</lastmod><changefreq>weekly</changefreq><priority>{priority}</priority></url>"
        )
    sitemap = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        + "\n".join(entries)
        + "\n</urlset>\n"
    )
    write_file("sitemap.xml", sitemap)
    write_file("robots.txt", f"User-agent: *\nAllow: /\nSitemap: {DOMAIN}/sitemap.xml\n")


def clean_generated_paths():
    for path in ["products", "pages"]:
        target = ROOT / path
        if target.exists():
            shutil.rmtree(target)
    DOCUMENTS_DIR.mkdir(exist_ok=True)


def main():
    raw_products = load_json(DATA_DIR / "products.json")
    raw_apps = load_json(DATA_DIR / "applications.json")
    groups = normalize_products(raw_products)
    apps = normalize_applications(raw_apps)

    clean_generated_paths()
    write_clean_data(groups, apps)

    urls = [("/", "1.0"), ("/products/", "0.9"), ("/pages/gioi-thieu.html", "0.7"), ("/pages/lien-he.html", "0.8"), ("/pages/ung-dung.html", "0.8")]
    write_file("index.html", render_home(groups, apps))
    write_file("products/index.html", render_products_index(groups, apps))
    write_file("pages/gioi-thieu.html", render_about(groups, apps))
    write_file("pages/lien-he.html", render_contact(groups, apps))
    write_file("pages/ung-dung.html", render_app_index(groups, apps))
    write_file("404.html", render_404(groups, apps))

    for group in groups:
        group_path = f"/products/{group['slug']}/"
        urls.append((group_path, "0.8"))
        write_file(f"products/{group['slug']}/index.html", render_group_page(group, groups, apps))
        for product in group["products"]:
            product_path = f"/products/{group['slug']}/{product['slug']}/"
            urls.append((product_path, "0.65"))
            write_file(f"products/{group['slug']}/{product['slug']}/index.html", render_product_page(product, group, groups, apps))

    for app in apps["applications"]:
        app_path = f"/pages/ung-dung/{app['slug']}/"
        urls.append((app_path, "0.65"))
        write_file(f"pages/ung-dung/{app['slug']}/index.html", render_app_detail(app, groups, apps))

    build_sitemap(urls)
    print(f"Đã build {sum(len(group['products']) for group in groups)} sản phẩm, {len(groups)} nhóm, {len(apps['applications'])} trang ứng dụng.")


if __name__ == "__main__":
    main()
