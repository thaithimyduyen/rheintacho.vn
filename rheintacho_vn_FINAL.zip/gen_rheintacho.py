#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_rheintacho.py — Static Site Generator cho rheintacho.com.vn
Build trang sản phẩm / nhóm / listing từ products.json + applications.json,
dùng design system rheintacho-design.css (.pd-*, .specs-table, .product-card...).

Đặc điểm:
- Header/footer nhúng inline (canonical = assets/components/{lang}/*.html)
- Toàn bộ ảnh .jpg/.jpeg/.png -> .webp tự động (nếu bản webp tồn tại)
- Bilingual VI/EN, slug riêng từng ngôn ngữ
- SEO: title, meta desc, canonical, OG, hreflang, Product schema, BreadcrumbList
"""

import json, os, re, shutil, html
from pathlib import Path

ROOT = Path(__file__).parent
ASSETS = ROOT / "assets"
IMG_DIR = ASSETS / "images"
DATA = ASSETS / "data"
COMPONENTS = ASSETS / "components"
DIST = ROOT / "dist"          # build ra đây, không đụng repo gốc

DOMAIN = "https://rheintacho.com.vn"
PHONE = "+84 938 888 958"
PHONE_TEL = "+84938888958"
EMAIL = "sales@rheintacho.vn"

# ── Tập webp có sẵn (để chỉ đổi khi thật sự có bản webp) ──────────────
WEBP_AVAILABLE = {p.name for p in IMG_DIR.glob("*.webp")}

def to_webp(src: str) -> str:
    """Đổi đuôi ảnh sang .webp NẾU bản webp tồn tại; nếu không, giữ nguyên."""
    if not src:
        return src
    # chỉ xử lý ảnh raster
    m = re.match(r"^(.*)\.(jpg|jpeg|png)$", src, re.IGNORECASE)
    if not m:
        return src
    base = m.group(1)
    webp_name = os.path.basename(base) + ".webp"
    if webp_name in WEBP_AVAILABLE:
        return base + ".webp"
    return src

def img_path(filename: str) -> str:
    """Trả về đường dẫn tuyệt đối /assets/images/<webp nếu có>."""
    if not filename:
        return ""
    fn = to_webp(filename)
    # nếu đã có /assets prefix thì giữ
    if fn.startswith("/") or fn.startswith("http"):
        return fn
    return f"/assets/images/{os.path.basename(fn)}"

def esc(s) -> str:
    return html.escape(str(s), quote=True) if s is not None else ""

def _dedup_pairs(pairs):
    """object_pairs_hook: giữ key trùng bằng cách thêm hậu tố __dupN."""
    d = {}
    for k, v in pairs:
        if k in d:
            i = 2
            while f"{k}__dup{i}" in d:
                i += 1
            d[f"{k}__dup{i}"] = v
        else:
            d[k] = v
    return d

def load_json(name):
    with open(DATA / name, encoding="utf-8") as f:
        return json.load(f, object_pairs_hook=_dedup_pairs)

def read_component(lang, name):
    p = COMPONENTS / lang / f"{name}.html"
    if not p.exists():
        p = COMPONENTS / "vi" / f"{name}.html"
    return p.read_text(encoding="utf-8")

# ── Chuẩn hoá products.json thành list phẳng ─────────────────────────
def flatten_products(prod):
    """Trả list dict: mỗi item = 1 sản phẩm với group context."""
    items = []
    groups = {}
    for gkey, gval in prod.items():
        if not isinstance(gval, dict):
            continue
        gslug = gval.get("slug", {})
        groups[gkey] = {
            "key": gkey,
            "slug": gslug,
            "description": gval.get("description", {}),
            "main_image": gval.get("main_image"),
            "products": [],
        }
        for pkey, pval in gval.items():
            if isinstance(pval, dict) and "name" in pval:
                pval = dict(pval)
                pval["_key"] = pkey
                pval["_group"] = gkey
                items.append(pval)
                groups[gkey]["products"].append(pval)
    return items, groups

# ── Trích Part-Number từ description (mã dạng N0000.219, H0000.xxx ...) ──
PART_RE = re.compile(r"\b([A-Z]\d{4}\.\d{2,4}[A-Z]?(?:-\d+)?)\b")
def extract_part_number(desc_html: str):
    if not desc_html:
        return None
    m = PART_RE.search(desc_html)
    return m.group(1) if m else None

# ── Phân biệt biến thể từ key (xử lý slug/name trùng) ──
def variant_descriptor(pkey, lang):
    """Trích thông tin phân biệt từ key sản phẩm (vd cáp M12 angled 2m)."""
    k = pkey.lower()
    parts_vi, parts_en = [], []
    # hướng cáp
    if "angled" in k:
        parts_vi.append("ra góc 90°"); parts_en.append("angled")
    elif "straight" in k:
        parts_vi.append("ra thẳng"); parts_en.append("straight")
    # độ dài cáp
    m = re.search(r"(\d+)m-cable", k)
    if m:
        parts_vi.append(f"cáp {m.group(1)}m"); parts_en.append(f"{m.group(1)}m cable")
    # dải LED cho AC adapter
    m2 = re.search(r"(\d+)-led-(\d+)-led", k)
    if m2:
        rng = f"{m2.group(1)}/{m2.group(2)} LED"
        parts_vi.append(f"cho {rng}"); parts_en.append(f"for {rng}")
    if lang == "en":
        return " ".join(parts_en)
    return " ".join(parts_vi)

def slugify(text):
    import unicodedata
    t = unicodedata.normalize("NFD", text)
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    t = t.replace("đ", "d").replace("Đ", "d")
    t = re.sub(r"[^a-zA-Z0-9]+", "-", t).strip("-").lower()
    return re.sub(r"-+", "-", t)

def unique_slug(p, lang):
    """Slug duy nhất: nếu có descriptor thì gắn thêm, đảm bảo không đè trang."""
    base = p["slug"].get(lang) or p["slug"].get("vi") or p["_key"]
    desc = variant_descriptor(p["_key"], lang)
    if desc:
        return slugify(base + "-" + desc)
    return base

def display_name(p, lang):
    name = p["name"].get(lang) or p["name"].get("vi", "")
    desc = variant_descriptor(p["_key"], lang)
    if desc:
        return f"{name} ({desc})"
    return name

# ── Tên nhóm chuẩn (data main_category không đáng tin) ──
GROUP_NAMES = {
    "rotational_speed_sensors":  {"vi": "Cảm biến tốc độ quay",        "en": "Rotational Speed Sensors"},
    "digital_hand_tachometers":  {"vi": "Tachometer cầm tay kỹ thuật số", "en": "Digital Hand Tachometers"},
    "portable_stroboscopes":     {"vi": "Stroboscope cầm tay",         "en": "Portable Stroboscopes"},
    "stationary_stroboscopes":   {"vi": "Stroboscope cố định",         "en": "Stationary Stroboscopes"},
    "others_products":           {"vi": "Rotas & sản phẩm khác",       "en": "Rotas & Other Products"},
    "accessories":               {"vi": "Phụ kiện & linh kiện",        "en": "Accessories"},
}
GROUP_DESC = {
    "rotational_speed_sensors":  {"vi": "Cảm biến tốc độ quay Rheintacho — công nghệ Hall, Differential Hall và GMR cho đo tốc độ chính xác trong môi trường công nghiệp nặng.",
                                   "en": "Rheintacho rotational speed sensors — Hall, Differential Hall and GMR technology for precise speed measurement in heavy industry."},
    "digital_hand_tachometers":  {"vi": "Tachometer cầm tay Rheintacho series Rotaro và Redpoint — đo tốc độ tiếp xúc và không tiếp xúc tại hiện trường.",
                                   "en": "Rheintacho Rotaro and Redpoint handheld tachometers — contact and non-contact speed measurement in the field."},
    "portable_stroboscopes":     {"vi": "Stroboscope cầm tay Rheintacho — kiểm tra chuyển động quay, phân tích rung động và bảo trì không tiếp xúc.",
                                   "en": "Rheintacho portable stroboscopes — rotational motion inspection, vibration analysis and non-contact maintenance."},
    "stationary_stroboscopes":   {"vi": "Stroboscope cố định Rheintacho — giám sát và kiểm tra chuyển động liên tục cho dây chuyền sản xuất.",
                                   "en": "Rheintacho stationary stroboscopes — continuous motion monitoring and inspection for production lines."},
    "others_products":           {"vi": "Bộ giám sát tốc độ quay Rotas và các giải pháp đo lường công nghiệp khác từ Rheintacho.",
                                   "en": "Rotas rotational speed monitors and other industrial measurement solutions from Rheintacho."},
    "accessories":               {"vi": "Phụ kiện và linh kiện Rheintacho — cáp, adapter, pin, bánh xe đo, đầu đo và tấm phản quang.",
                                   "en": "Rheintacho accessories and spare parts — cables, adapters, batteries, measuring wheels, tips and reflective tapes."},
}

UI = {
    "vi": {
        "home": "Trang chủ", "products": "Sản phẩm",
        "specs": "Thông số kỹ thuật", "features": "Tính năng nổi bật",
        "downloads": "Tài liệu & Datasheet", "scope": "Phạm vi giao hàng",
        "apps": "Ứng dụng tiêu biểu", "related": "Sản phẩm liên quan",
        "cta_p": "Cần tư vấn kỹ thuật hoặc báo giá cho ứng dụng cụ thể?",
        "quote": "Yêu cầu báo giá", "call": "Gọi kỹ thuật",
        "view": "Xem chi tiết", "datasheet": "Tải về (PDF)",
        "all_in": "Tất cả sản phẩm trong",
    },
    "en": {
        "home": "Home", "products": "Products",
        "specs": "Technical Specifications", "features": "Key Features",
        "downloads": "Documents & Datasheets", "scope": "Scope of Delivery",
        "apps": "Typical Applications", "related": "Related Products",
        "cta_p": "Need technical advice or a quotation for your application?",
        "quote": "Request a Quote", "call": "Call Technical",
        "view": "View details", "datasheet": "Download (PDF)",
        "all_in": "All products in",
    },
}

ICON_ARROW = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>'
ICON_PHONE = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>'
ICON_DOC = '<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>'

def render_specs(spec_dict, lang):
    if not spec_dict:
        return ""
    rows = "".join(
        f"<tr><td>{esc(k)}</td><td>{esc(v)}</td></tr>"
        for k, v in spec_dict.items() if str(v).strip()
    )
    if not rows:
        return ""
    return (f'<div class="pd-specs"><h3>{UI[lang]["specs"]}</h3>'
            f'<table class="specs-table"><tbody>{rows}</tbody></table></div>')

def render_features(feats, lang):
    feats = [f for f in (feats or []) if str(f).strip()]
    if not feats:
        return ""
    lis = "".join(f"<li>{esc(f)}</li>" for f in feats)
    return (f'<div class="pd-specs"><h3>{UI[lang]["features"]}</h3>'
            f'<ul class="pd-feature-list">{lis}</ul></div>')

def render_downloads(docs, lang):
    docs = [d for d in (docs or []) if str(d).strip()]
    if not docs:
        return ""
    links = ""
    for d in docs:
        name = os.path.basename(d)
        href = d if d.startswith(("/", "http")) else f"/assets/files/{name}"
        label = name.replace("_", " ").replace(".pdf", "")
        links += (f'<a class="download-link" href="{esc(href)}" target="_blank" rel="noopener">'
                  f'{ICON_DOC}<span>{esc(label)}</span>'
                  f'<span class="download-size">PDF</span></a>')
    return (f'<div class="pd-downloads"><h3>{UI[lang]["downloads"]}</h3>'
            f'<div class="download-list">{links}</div></div>')

def render_gallery(images, name, lang):
    images = [i for i in (images or []) if str(i).strip()]
    if not images:
        main = '<div class="pd-main-img"></div>'
        return f'<div class="pd-gallery">{main}</div>'
    main = (f'<div class="pd-main-img">'
            f'<img src="{img_path(images[0])}" alt="{esc(name)} — Rheintacho" loading="eager"></div>')
    thumbs = ""
    if len(images) > 1:
        ts = "".join(
            f'<div class="pd-thumb"><img src="{img_path(im)}" alt="{esc(name)} {idx+2}" loading="lazy"></div>'
            for idx, im in enumerate(images[1:8])
        )
        thumbs = f'<div class="pd-thumbs">{ts}</div>'
    return f'<div class="pd-gallery">{main}{thumbs}</div>'

def render_breadcrumb(crumbs, lang):
    """crumbs = [(label, href), ...]; phần tử cuối là current (href=None)."""
    parts = []
    for i, (label, href) in enumerate(crumbs):
        if href:
            parts.append(f'<a href="{esc(href)}">{esc(label)}</a>')
        else:
            parts.append(f'<span class="current">{esc(label)}</span>')
        if i < len(crumbs) - 1:
            parts.append('<span class="sep">/</span>')
    return f'<nav class="rt-breadcrumb" aria-label="breadcrumb">{"".join(parts)}</nav>'

def breadcrumb_schema(crumbs):
    items = []
    pos = 1
    for label, href in crumbs:
        entry = {"@type": "ListItem", "position": pos, "name": label}
        if href:
            entry["item"] = DOMAIN + href if href.startswith("/") else href
        items.append(entry)
        pos += 1
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": items}

def product_schema(name, desc, image, url):
    return {
        "@context": "https://schema.org/", "@type": "Product",
        "name": name, "image": [image] if image else [],
        "description": desc, "sku": name,
        "brand": {"@type": "Brand", "name": "Rheintacho"},
        "manufacturer": {"@type": "Organization", "name": "Rheintacho",
                         "address": {"@type": "PostalAddress", "addressCountry": "Germany"}},
        "offers": {"@type": "Offer", "priceCurrency": "VND",
                   "availability": "https://schema.org/InStock", "url": url,
                   "seller": {"@type": "Organization", "name": "Fast Group Engineering"}},
    }

def page_shell(lang, title, desc, canonical, body, image="", schemas=None,
               url_vi="", url_en="", index=True):
    header = read_component(lang, "header")
    footer = read_component(lang, "footer")
    schema_block = ""
    for sc in (schemas or []):
        schema_block += ('<script type="application/ld+json">'
                         + json.dumps(sc, ensure_ascii=False) + '</script>\n')
    robots = "index, follow" if index else "noindex, follow"
    og_img = image or f"{DOMAIN}/assets/images/main_logo.webp"
    locale = "vi_VN" if lang == "vi" else "en_US"
    return f"""<!DOCTYPE html>
<html lang="{lang}">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{esc(title)}</title>
<meta name="description" content="{esc(desc)}" />
<meta name="robots" content="{robots}" />
<link rel="canonical" href="{esc(canonical)}" />
<meta property="og:title" content="{esc(title)}" />
<meta property="og:description" content="{esc(desc)}" />
<meta property="og:image" content="{esc(og_img)}" />
<meta property="og:url" content="{esc(canonical)}" />
<meta property="og:type" content="product" />
<meta property="og:locale" content="{locale}" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="{esc(title)}" />
<meta name="twitter:description" content="{esc(desc)}" />
<meta name="twitter:image" content="{esc(og_img)}" />
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png" />
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon-32x32.png" />
<link rel="icon" type="image/png" sizes="16x16" href="/assets/images/favicon-16x16.png" />
<link rel="manifest" href="/assets/images/site.webmanifest" />
{f'<link rel="alternate" hreflang="vi" href="{esc(url_vi)}" />' if url_vi else ''}
{f'<link rel="alternate" hreflang="en" href="{esc(url_en)}" />' if url_en else ''}
{f'<link rel="alternate" hreflang="x-default" href="{esc(url_vi or url_en)}" />' if (url_vi or url_en) else ''}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="/assets/css/bootstrap.min.css" rel="stylesheet" />
<link href="/assets/css/rheintacho-design.css" rel="stylesheet" />
{schema_block}</head>
<body>
{header}
{body}
{footer}
<script src="/assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>"""

# ── TRANG SẢN PHẨM ───────────────────────────────────────────────────
def build_product_page(p, lang, groups):
    name = display_name(p, lang)
    short = p.get("short_description", {}).get(lang, "")
    desc = p.get("description", {}).get(lang, "")
    gkey = p["_group"]
    gslug = groups[gkey]["slug"].get(lang, gkey)
    pslug = unique_slug(p, lang)
    cat = p.get("category", {}).get(lang, "")
    part = extract_part_number(p.get("description", {}).get("vi", ""))

    base = f"/{lang}/{gslug}/{pslug}/"
    url = DOMAIN + base
    url_vi = f"{DOMAIN}/vi/{groups[gkey]['slug'].get('vi', gkey)}/{unique_slug(p, 'vi')}/"
    url_en = f"{DOMAIN}/en/{groups[gkey]['slug'].get('en', gkey)}/{unique_slug(p, 'en')}/"
    main_img = img_path(p["images"][0]) if p.get("images") else ""
    img_abs = DOMAIN + main_img if main_img else ""

    u = UI[lang]
    group_name = GROUP_NAMES.get(gkey, {}).get(lang) or gslug.replace("-", " ").title()
    crumbs = [
        (u["home"], f"/{lang}/"),
        (u["products"], f"/{lang}/categories.html"),
        (group_name, f"/{lang}/{gslug}/"),
        (name, None),
    ]
    crumbs = [c for c in crumbs if c[0]]

    gallery = render_gallery(p.get("images"), name, lang)
    specs = render_specs(p.get("technical_data", {}).get(lang, {}), lang)
    feats = render_features(p.get("features", {}).get(lang, []), lang)
    downloads = render_downloads(p.get("docs", []), lang)

    model_line = f'<div class="pd-model">{esc(part)}</div>' if part else \
                 (f'<div class="pd-model">{esc(cat)}</div>' if cat else "")
    desc_html = desc if desc.strip().startswith("<") else f"<p>{esc(desc)}</p>"

    cta = f"""<div class="pd-cta">
  <p>{u['cta_p']}</p>
  <div class="pd-cta-actions">
    <a class="btn-primary-rt" href="/{lang}/contact.html">{u['quote']} {ICON_ARROW}</a>
    <a class="btn-outline-rt" href="tel:{PHONE_TEL}">{ICON_PHONE} {u['call']}</a>
  </div>
</div>"""

    body = f"""
<section class="product-detail">
  <div class="container">
    {render_breadcrumb(crumbs, lang)}
    <div class="pd-grid">
      {gallery}
      <div class="pd-info">
        {model_line}
        <h1 class="pd-name">{esc(name)}</h1>
        <div class="pd-desc">{desc_html}</div>
        {feats}
        {specs}
        {downloads}
        {cta}
      </div>
    </div>
  </div>
</section>"""

    title = f"{name} – {group_name} | Rheintacho Việt Nam" if lang == "vi" \
            else f"{name} – {group_name} | Rheintacho Vietnam"
    metadesc = short or (re.sub("<[^>]+>", "", desc)[:155])
    schemas = [product_schema(name, metadesc, img_abs, url), breadcrumb_schema(crumbs)]
    return base, page_shell(lang, title, metadesc, url, body, image=img_abs,
                            schemas=schemas, url_vi=url_vi, url_en=url_en, index=True)

def render_product_card(p, lang, groups):
    name = display_name(p, lang)
    short = p.get("short_description", {}).get(lang, "")
    gkey = p["_group"]
    gslug = groups[gkey]["slug"].get(lang, gkey)
    pslug = unique_slug(p, lang)
    href = f"/{lang}/{gslug}/{pslug}/"
    img = img_path(p["images"][0]) if p.get("images") else "/assets/images/main_logo.webp"
    cat = p.get("category", {}).get(lang, "")
    u = UI[lang]
    short_txt = re.sub("<[^>]+>", "", short)[:90]
    return f"""<a class="product-card" href="{esc(href)}">
  <div class="product-card-img"><img src="{img}" alt="{esc(name)}" loading="lazy"></div>
  <div class="product-card-body">
    {f'<span class="product-card-cat">{esc(cat)}</span>' if cat else ''}
    <h3 class="product-card-name">{esc(name)}</h3>
    {f'<p class="product-card-desc">{esc(short_txt)}</p>' if short_txt else ''}
    <span class="product-card-link">{u['view']} {ICON_ARROW}</span>
  </div>
</a>"""

def build_group_page(gkey, glob_groups, lang):
    g = glob_groups[gkey]
    gslug = g["slug"].get(lang, gkey)
    gname = GROUP_NAMES.get(gkey, {}).get(lang) or gslug.replace("-", " ").title()
    gdesc_txt = GROUP_DESC.get(gkey, {}).get(lang, f"{UI[lang]['all_in']} {gname} — Rheintacho.")
    u = UI[lang]
    base = f"/{lang}/{gslug}/"
    url = DOMAIN + base
    crumbs = [(u["home"], f"/{lang}/"), (u["products"], f"/{lang}/categories.html"), (gname, None)]
    cards = "".join(render_product_card(p, lang, glob_groups) for p in g["products"])
    body = f"""
<section class="group-hero">
  <div class="container">
    {render_breadcrumb(crumbs, lang)}
    <h1>{esc(gname)}</h1>
    <p>{esc(gdesc_txt)}</p>
  </div>
</section>
<section class="container">
  <div class="group-grid">{cards}</div>
</section>"""
    title = f"{gname} | Rheintacho Việt Nam" if lang == "vi" else f"{gname} | Rheintacho Vietnam"
    schemas = [breadcrumb_schema(crumbs)]
    return base, page_shell(lang, title, gdesc_txt, url, body, schemas=schemas, index=True)

def build_all(lang="vi", do_assets=True):
    prod = load_json("products.json")
    items, groups = flatten_products(prod)
    if do_assets and not (DIST / "assets").exists():
        shutil.copytree(ASSETS, DIST / "assets")
    n_prod = n_group = 0
    for p in items:
        base, html_out = build_product_page(p, lang, groups)
        out = DIST / base.lstrip("/") / "index.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html_out, encoding="utf-8")
        n_prod += 1
    for gkey in groups:
        base, html_out = build_group_page(gkey, groups, lang)
        out = DIST / base.lstrip("/") / "index.html"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html_out, encoding="utf-8")
        n_group += 1
    return n_prod, n_group

def build_sitemap(langs):
    """Sinh sitemap cho từng ngôn ngữ + index, gồm trang sản phẩm & nhóm."""
    from datetime import date
    today = date.today().isoformat()
    prod = load_json("products.json")
    items, groups = flatten_products(prod)
    index_maps = []
    for lang in langs:
        urls = []
        # trang nhóm
        for gkey in groups:
            gslug = groups[gkey]["slug"].get(lang, gkey)
            urls.append((f"{DOMAIN}/{lang}/{gslug}/", "0.8"))
        # trang sản phẩm
        for p in items:
            gkey = p["_group"]
            gslug = groups[gkey]["slug"].get(lang, gkey)
            pslug = unique_slug(p, lang)
            urls.append((f"{DOMAIN}/{lang}/{gslug}/{pslug}/", "0.7"))
        body = "".join(
            f"  <url><loc>{esc(u)}</loc><lastmod>{today}</lastmod>"
            f"<changefreq>monthly</changefreq><priority>{pr}</priority></url>\n"
            for u, pr in urls
        )
        xml = ('<?xml version="1.0" encoding="UTF-8"?>\n'
               '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
               f"{body}</urlset>\n")
        out = DIST / f"sitemap-{lang}-products.xml"
        out.write_text(xml, encoding="utf-8")
        index_maps.append(f"sitemap-{lang}-products.xml")
        print(f"✓ sitemap-{lang}-products.xml: {len(urls)} URLs")
    # index
    idx_body = "".join(
        f"  <sitemap><loc>{DOMAIN}/{m}</loc><lastmod>{today}</lastmod></sitemap>\n"
        for m in index_maps
    )
    idx = ('<?xml version="1.0" encoding="UTF-8"?>\n'
           '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
           f"{idx_body}</sitemapindex>\n")
    (DIST / "sitemap-products-index.xml").write_text(idx, encoding="utf-8")
    print(f"✓ sitemap-products-index.xml: {len(index_maps)} sitemaps")

if __name__ == "__main__":
    import sys
    if (DIST / "assets").exists():
        shutil.copy(ASSETS / "css" / "rheintacho-design.css",
                    DIST / "assets" / "css" / "rheintacho-design.css")
    langs = sys.argv[1:] or ["vi"]   # mặc định VI; truyền 'en' để build thêm
    total_p = total_g = 0
    for lang in langs:
        np, ng = build_all(lang)
        total_p += np; total_g += ng
        print(f"✓ {lang.upper()} build: {np} trang sản phẩm + {ng} trang nhóm")
    shutil.copy(ASSETS / "css" / "rheintacho-design.css",
                DIST / "assets" / "css" / "rheintacho-design.css")
    build_sitemap(langs)
    print(f"✓ TỔNG: {total_p} sản phẩm + {total_g} nhóm = {total_p+total_g} trang")
