#!/usr/bin/env python3
"""
Phase 4B — Image Optimization Script
rheintacho.com.vn | FAST GROUP ENGINEERING
Usage: python3 assets/optimize_images.py
Requires: pip install Pillow --break-system-packages
"""

import os
from pathlib import Path
from PIL import Image

ASSETS_DIR = Path(__file__).parent / "images"
MAX_WIDTH = 800
WEBP_QUALITY = 80
PNG_QUALITY = 60

# Icons that need extra compression (max 200x200)
ICON_NAMES = {"genuine.png", "vat.png", "support.png", "delivery.png"}

def format_size(bytes_val):
    return f"{bytes_val/1024:.1f} KB"

def process_image(path: Path):
    original_size = path.stat().st_size
    ext = path.suffix.lower()
    
    with Image.open(path) as img:
        orig_w, orig_h = img.size
        needs_resize = False
        
        # Determine target size
        if path.name in ICON_NAMES:
            max_dim = 200
            needs_resize = orig_w > max_dim or orig_h > max_dim
        else:
            max_dim = MAX_WIDTH
            needs_resize = orig_w > max_dim

        if needs_resize:
            if path.name in ICON_NAMES:
                img.thumbnail((max_dim, max_dim), Image.LANCZOS)
            else:
                ratio = max_dim / orig_w
                new_h = int(orig_h * ratio)
                img = img.resize((max_dim, new_h), Image.LANCZOS)
            resized = True
        else:
            resized = False

        # Save compressed original back (only if resized or PNG icon)
        if resized or (ext == ".png" and path.name in ICON_NAMES):
            if ext == ".png":
                img.save(path, "PNG", optimize=True, quality=PNG_QUALITY)
            else:
                img.save(path, "JPEG", quality=85, optimize=True)
            
            new_size = path.stat().st_size
            saving_pct = (1 - new_size / original_size) * 100
            action = "resized+compressed" if resized else "compressed"
            print(f"  [{action}] {path.name}: {format_size(original_size)} → {format_size(new_size)} ({saving_pct:.0f}% saved)")
        else:
            new_size = original_size
            print(f"  [skip]   {path.name}: {format_size(original_size)} (already optimal size)")

        # Create WebP version
        webp_path = path.with_suffix(".webp")
        if not webp_path.exists():
            if img.mode in ("RGBA", "P"):
                img = img.convert("RGBA")
            else:
                img = img.convert("RGB")
            img.save(webp_path, "WEBP", quality=WEBP_QUALITY, method=6)
            webp_size = webp_path.stat().st_size
            webp_saving = (1 - webp_size / original_size) * 100
            print(f"  [webp]   → {webp_path.name}: {format_size(webp_size)} ({webp_saving:.0f}% vs original)")

def main():
    images = list(ASSETS_DIR.glob("*.jpg")) + list(ASSETS_DIR.glob("*.png")) + \
             list(ASSETS_DIR.glob("*.jpeg"))
    
    print(f"Processing {len(images)} images in {ASSETS_DIR}\n")
    
    total_orig = 0
    total_new = 0
    webp_count = 0
    
    for img_path in sorted(images):
        orig_size = img_path.stat().st_size
        total_orig += orig_size
        process_image(img_path)
        total_new += img_path.stat().st_size
        
        webp = img_path.with_suffix(".webp")
        if webp.exists():
            webp_count += 1
    
    print(f"\n{'='*50}")
    print(f"Summary:")
    print(f"  Original total:  {format_size(total_orig)}")
    print(f"  After compress:  {format_size(total_new)}")
    print(f"  Savings:         {format_size(total_orig - total_new)} ({(1-total_new/total_orig)*100:.0f}%)")
    print(f"  WebP created:    {webp_count} files")
    print()
    print("Picture tag template for WebP with fallback:")
    print("""
  <picture>
    <source srcset="/assets/images/[name].webp" type="image/webp">
    <img src="/assets/images/[name].jpg" alt="..." loading="lazy" width="572" height="386">
  </picture>
""")

if __name__ == "__main__":
    main()
