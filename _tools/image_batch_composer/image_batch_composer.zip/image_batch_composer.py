from __future__ import annotations

import csv
import os
import queue
import threading
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Tuple

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox, ttk

from PIL import Image, ImageColor, ImageOps, ImageTk


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}
CANVAS_PRESETS = ["600x800", "800x1000", "1000x1000", "1200x1200", "Tự nhập"]
BACKGROUND_LABELS = {
    "Trong suốt": "transparent",
    "Trắng": "white",
    "Màu tự chọn": "color",
    "Ảnh nền": "image",
}
BACKGROUND_LABEL_BY_MODE = {value: key for key, value in BACKGROUND_LABELS.items()}
OUTPUT_FORMATS = ["PNG", "JPG", "WEBP"]


@dataclass(frozen=True)
class AppSettings:
    input_files: Tuple[Path, ...]
    input_folder: Optional[Path]
    include_subfolders: bool
    output_folder: Path
    preserve_structure: bool
    overwrite: bool
    output_format: str
    quality: int
    canvas_size: Tuple[int, int]
    background_mode: str
    background_color: str
    background_image: Optional[Path]
    product_scale: int
    trim_transparent: bool
    offset_x: int
    offset_y: int
    override_csv: Optional[Path]


@dataclass(frozen=True)
class ImageOverride:
    background_mode: Optional[str] = None
    background_color: Optional[str] = None
    background_image: Optional[Path] = None
    product_scale: Optional[int] = None
    canvas_size: Optional[Tuple[int, int]] = None
    output_format: Optional[str] = None
    quality: Optional[int] = None


def is_image_file(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS


def parse_canvas_size(text: str) -> Tuple[int, int]:
    normalized = text.lower().replace(" ", "")
    if "x" not in normalized:
        raise ValueError("Kích thước khung phải có dạng rộng x cao, ví dụ 800x1000.")
    width_text, height_text = normalized.split("x", 1)
    width = int(width_text)
    height = int(height_text)
    if width <= 0 or height <= 0:
        raise ValueError("Chiều rộng và chiều cao phải lớn hơn 0.")
    return width, height


def color_to_hex(value: str) -> str:
    rgb = ImageColor.getrgb(value.strip())
    return "#{:02x}{:02x}{:02x}".format(rgb[0], rgb[1], rgb[2])


def normalize_match_key(value: str) -> str:
    cleaned = value.strip().replace("\\", "/").lstrip("./")
    return cleaned.lower()


def resolve_relative_path(value: str, base_dir: Path) -> Path:
    path = Path(value.strip().strip('"'))
    if path.is_absolute():
        return path
    return base_dir / path


def first_row_value(row: Dict[str, str], *keys: str) -> str:
    lowered = {key.lower().strip(): value for key, value in row.items()}
    for key in keys:
        value = lowered.get(key.lower())
        if value:
            return value.strip()
    return ""


def optional_int(value: str, minimum: int, maximum: int) -> Optional[int]:
    if not value:
        return None
    parsed = int(float(value))
    return max(minimum, min(maximum, parsed))


def load_overrides(csv_path: Optional[Path]) -> Dict[str, ImageOverride]:
    if not csv_path:
        return {}

    overrides: Dict[str, ImageOverride] = {}
    base_dir = csv_path.parent
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            image_key = first_row_value(row, "image", "file", "filename", "path", "anh")
            if not image_key:
                continue

            bg_mode: Optional[str] = None
            bg_color: Optional[str] = None
            bg_image: Optional[Path] = None

            bg_text = first_row_value(row, "background", "bg", "nen", "nền")
            color_text = first_row_value(row, "color", "background_color", "mau", "màu")
            bg_image_text = first_row_value(
                row,
                "background_image",
                "bg_image",
                "image_background",
                "hinh_nen",
                "hình_nền",
            )

            if bg_image_text:
                bg_mode = "image"
                bg_image = resolve_relative_path(bg_image_text, base_dir)
            elif bg_text:
                lower_bg = bg_text.lower()
                if lower_bg in {"transparent", "none", "trong suot", "trong suốt"}:
                    bg_mode = "transparent"
                elif lower_bg in {"white", "trang", "trắng"}:
                    bg_mode = "white"
                else:
                    try:
                        bg_color = color_to_hex(bg_text)
                        bg_mode = "color"
                    except ValueError:
                        bg_mode = "image"
                        bg_image = resolve_relative_path(bg_text, base_dir)

            if color_text:
                bg_mode = "color"
                bg_color = color_to_hex(color_text)

            scale = optional_int(first_row_value(row, "scale", "product_scale", "ty_le", "tỷ_lệ"), 10, 250)

            canvas_width = optional_int(first_row_value(row, "canvas_width", "width", "rong", "rộng"), 1, 20000)
            canvas_height = optional_int(first_row_value(row, "canvas_height", "height", "cao"), 1, 20000)
            canvas_size = (canvas_width, canvas_height) if canvas_width and canvas_height else None

            output_format = first_row_value(row, "format", "output_format", "dinh_dang", "định_dạng").upper()
            if output_format == "JPEG":
                output_format = "JPG"
            if output_format not in OUTPUT_FORMATS:
                output_format = None

            quality = optional_int(first_row_value(row, "quality", "chat_luong", "chất_lượng"), 1, 100)

            overrides[normalize_match_key(image_key)] = ImageOverride(
                background_mode=bg_mode,
                background_color=bg_color,
                background_image=bg_image,
                product_scale=scale,
                canvas_size=canvas_size,
                output_format=output_format,
                quality=quality,
            )

    return overrides


def find_override(
    image_path: Path,
    input_root: Path,
    overrides: Dict[str, ImageOverride],
) -> Optional[ImageOverride]:
    if not overrides:
        return None

    candidates = []
    try:
        candidates.append(image_path.relative_to(input_root).as_posix())
    except ValueError:
        pass
    candidates.extend([image_path.name, image_path.stem])

    for candidate in candidates:
        override = overrides.get(normalize_match_key(candidate))
        if override:
            return override
    return None


def gather_input_images(settings: AppSettings) -> Tuple[List[Path], Path]:
    if settings.input_folder:
        input_root = settings.input_folder
        pattern = "**/*" if settings.include_subfolders else "*"
        exclude_output = (
            settings.include_subfolders
            and settings.output_folder != input_root
            and path_is_inside(settings.output_folder, input_root)
        )
        images = sorted(
            path
            for path in input_root.glob(pattern)
            if is_image_file(path) and not (exclude_output and path_is_inside(path, settings.output_folder))
        )
        return images, input_root

    images = [path for path in settings.input_files if is_image_file(path)]
    if not images:
        raise ValueError("Chưa có ảnh đầu vào hợp lệ.")

    parent_paths = [str(path.parent) for path in images]
    try:
        input_root = Path(os.path.commonpath(parent_paths))
    except ValueError:
        input_root = images[0].parent
    return images, input_root


def path_is_inside(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def trim_transparent_edges(image: Image.Image) -> Image.Image:
    if image.mode != "RGBA":
        return image
    alpha = image.getchannel("A")
    bbox = alpha.getbbox()
    if not bbox:
        return image
    return image.crop(bbox)


def make_background(
    size: Tuple[int, int],
    mode: str,
    color: str,
    image_path: Optional[Path],
) -> Image.Image:
    width, height = size
    if mode == "transparent":
        return Image.new("RGBA", size, (0, 0, 0, 0))
    if mode == "white":
        return Image.new("RGBA", size, (255, 255, 255, 255))
    if mode == "color":
        rgb = ImageColor.getrgb(color)
        return Image.new("RGBA", size, (rgb[0], rgb[1], rgb[2], 255))
    if mode == "image":
        if not image_path:
            raise ValueError("Bạn đã chọn nền ảnh nhưng chưa chọn file ảnh nền.")
        with Image.open(image_path) as background:
            background = ImageOps.exif_transpose(background).convert("RGBA")
            return ImageOps.fit(
                background,
                (width, height),
                method=Image.Resampling.LANCZOS,
                centering=(0.5, 0.5),
            )
    raise ValueError(f"Kiểu nền không hợp lệ: {mode}")


def compose_image(
    image_path: Path,
    settings: AppSettings,
    override: Optional[ImageOverride] = None,
) -> Image.Image:
    canvas_size = override.canvas_size if override and override.canvas_size else settings.canvas_size
    background_mode = override.background_mode if override and override.background_mode else settings.background_mode
    background_color = override.background_color if override and override.background_color else settings.background_color
    background_image = override.background_image if override and override.background_image else settings.background_image
    product_scale = override.product_scale if override and override.product_scale else settings.product_scale

    canvas = make_background(canvas_size, background_mode, background_color, background_image)
    with Image.open(image_path) as source:
        foreground = ImageOps.exif_transpose(source).convert("RGBA")

    if settings.trim_transparent:
        foreground = trim_transparent_edges(foreground)

    max_width = max(1, int(canvas_size[0] * product_scale / 100))
    max_height = max(1, int(canvas_size[1] * product_scale / 100))
    ratio = min(max_width / foreground.width, max_height / foreground.height)
    resized_size = (
        max(1, int(round(foreground.width * ratio))),
        max(1, int(round(foreground.height * ratio))),
    )
    foreground = foreground.resize(resized_size, Image.Resampling.LANCZOS)

    x = (canvas_size[0] - foreground.width) // 2 + settings.offset_x
    y = (canvas_size[1] - foreground.height) // 2 + settings.offset_y

    layer = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
    layer.paste(foreground, (x, y), foreground)
    return Image.alpha_composite(canvas, layer)


def output_extension(output_format: str) -> str:
    if output_format == "JPG":
        return ".jpg"
    return "." + output_format.lower()


def unique_destination(path: Path, used_paths: set[str], overwrite: bool) -> Path:
    key = str(path).lower()
    if overwrite:
        used_paths.add(key)
        return path

    candidate = path
    index = 2
    while candidate.exists() or str(candidate).lower() in used_paths:
        candidate = path.with_name(f"{path.stem}_{index}{path.suffix}")
        index += 1
    used_paths.add(str(candidate).lower())
    return candidate


def build_output_path(
    image_path: Path,
    input_root: Path,
    settings: AppSettings,
    output_format: str,
    used_paths: set[str],
) -> Path:
    extension = output_extension(output_format)
    if settings.preserve_structure:
        try:
            relative_path = image_path.relative_to(input_root)
        except ValueError:
            relative_path = Path(image_path.name)
        destination = settings.output_folder / relative_path.with_suffix(extension)
    else:
        destination = settings.output_folder / f"{image_path.stem}{extension}"
    return unique_destination(destination, used_paths, settings.overwrite)


def save_output(image: Image.Image, destination: Path, output_format: str, quality: int) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    save_kwargs = {}

    if output_format == "JPG":
        output = Image.new("RGB", image.size, (255, 255, 255))
        if image.mode == "RGBA":
            output.paste(image, mask=image.getchannel("A"))
        else:
            output.paste(image)
        save_kwargs.update({"format": "JPEG", "quality": quality, "optimize": True})
    elif output_format == "WEBP":
        output = image
        save_kwargs.update({"format": "WEBP", "quality": quality, "method": 6})
    else:
        output = image
        save_kwargs.update({"format": "PNG", "optimize": True})

    output.save(destination, **save_kwargs)


def process_images(
    settings: AppSettings,
    log: Callable[[str], None],
    progress: Callable[[int, int], None],
) -> Tuple[int, int]:
    images, input_root = gather_input_images(settings)
    if not images:
        raise ValueError("Không tìm thấy ảnh trong nguồn đã chọn.")

    overrides = load_overrides(settings.override_csv)
    used_paths: set[str] = set()
    success_count = 0
    fail_count = 0

    settings.output_folder.mkdir(parents=True, exist_ok=True)
    progress(0, len(images))
    log(f"Tìm thấy {len(images)} ảnh.")

    for index, image_path in enumerate(images, start=1):
        try:
            override = find_override(image_path, input_root, overrides)
            output_format = (
                override.output_format if override and override.output_format else settings.output_format
            )
            quality = override.quality if override and override.quality else settings.quality
            composed = compose_image(image_path, settings, override)
            destination = build_output_path(image_path, input_root, settings, output_format, used_paths)
            save_output(composed, destination, output_format, quality)
            success_count += 1
            log(f"[OK] {image_path.name} -> {destination}")
        except Exception as exc:
            fail_count += 1
            log(f"[LỖI] {image_path}: {exc}")
        progress(index, len(images))

    return success_count, fail_count


def short_path(path: Optional[Path], max_length: int = 78) -> str:
    if not path:
        return "Chưa chọn"
    text = str(path)
    if len(text) <= max_length:
        return text
    return "..." + text[-(max_length - 3) :]


class ImageBatchComposerApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Ghép nền và resize ảnh hàng loạt")
        self.root.geometry("1180x780")
        self.root.minsize(980, 680)

        self.selected_files: List[Path] = []
        self.selected_folder: Optional[Path] = None
        self.output_folder: Optional[Path] = None
        self.background_image: Optional[Path] = None
        self.override_csv: Optional[Path] = None
        self.preview_photo: Optional[ImageTk.PhotoImage] = None
        self.worker_thread: Optional[threading.Thread] = None
        self.events: queue.Queue[Tuple[str, object]] = queue.Queue()

        self.include_subfolders_var = tk.BooleanVar(value=True)
        self.preserve_structure_var = tk.BooleanVar(value=True)
        self.overwrite_var = tk.BooleanVar(value=False)
        self.trim_transparent_var = tk.BooleanVar(value=True)
        self.canvas_preset_var = tk.StringVar(value="800x1000")
        self.canvas_width_var = tk.StringVar(value="800")
        self.canvas_height_var = tk.StringVar(value="1000")
        self.background_label_var = tk.StringVar(value="Trắng")
        self.background_color_var = tk.StringVar(value="#ffffff")
        self.output_format_var = tk.StringVar(value="PNG")
        self.quality_var = tk.IntVar(value=92)
        self.scale_var = tk.IntVar(value=90)
        self.offset_x_var = tk.IntVar(value=0)
        self.offset_y_var = tk.IntVar(value=0)
        self.status_var = tk.StringVar(value="Sẵn sàng.")
        self.input_summary_var = tk.StringVar(value="Chưa chọn nguồn ảnh")
        self.output_summary_var = tk.StringVar(value="Chưa chọn nơi xuất")
        self.bg_image_summary_var = tk.StringVar(value="Chưa chọn ảnh nền")
        self.csv_summary_var = tk.StringVar(value="Không dùng file CSV riêng")
        self.scale_text_var = tk.StringVar(value="90%")
        self.quality_text_var = tk.StringVar(value="92")

        self.setup_style()
        self.build_layout()
        self.refresh_background_controls()
        self.poll_events()

    def setup_style(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Title.TLabel", font=("Segoe UI", 13, "bold"))
        style.configure("Section.TLabelframe.Label", font=("Segoe UI", 10, "bold"))
        style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"))

    def build_layout(self) -> None:
        main = ttk.Frame(self.root, padding=14)
        main.grid(row=0, column=0, sticky="nsew")
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main.columnconfigure(0, weight=0)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=1)
        main.rowconfigure(1, weight=0)

        controls = ttk.Frame(main)
        controls.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        controls.columnconfigure(0, weight=1)

        preview_area = ttk.Frame(main)
        preview_area.grid(row=0, column=1, sticky="nsew")
        preview_area.columnconfigure(0, weight=1)
        preview_area.rowconfigure(1, weight=1)

        self.build_input_section(controls)
        self.build_output_section(controls)
        self.build_background_section(controls)
        self.build_canvas_section(controls)
        self.build_format_section(controls)
        self.build_action_section(controls)
        self.build_preview_section(preview_area)
        self.build_log_section(main)

    def build_input_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="1. Nguồn ảnh", style="Section.TLabelframe")
        frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        frame.columnconfigure(0, weight=1)

        ttk.Label(frame, textvariable=self.input_summary_var, wraplength=420).grid(
            row=0, column=0, columnspan=3, sticky="ew", padx=10, pady=(10, 6)
        )
        ttk.Button(frame, text="Chọn ảnh...", command=self.choose_files).grid(
            row=1, column=0, sticky="ew", padx=(10, 4), pady=4
        )
        ttk.Button(frame, text="Chọn folder...", command=self.choose_input_folder).grid(
            row=1, column=1, sticky="ew", padx=4, pady=4
        )
        ttk.Button(frame, text="Xóa chọn", command=self.clear_input).grid(
            row=1, column=2, sticky="ew", padx=(4, 10), pady=4
        )
        ttk.Checkbutton(
            frame,
            text="Quét cả sub-folder khi chọn folder",
            variable=self.include_subfolders_var,
        ).grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=(4, 10))

    def build_output_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="2. Nơi xuất", style="Section.TLabelframe")
        frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        frame.columnconfigure(0, weight=1)

        ttk.Label(frame, textvariable=self.output_summary_var, wraplength=420).grid(
            row=0, column=0, columnspan=2, sticky="ew", padx=10, pady=(10, 6)
        )
        ttk.Button(frame, text="Chọn folder xuất...", command=self.choose_output_folder).grid(
            row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=4
        )
        ttk.Checkbutton(
            frame,
            text="Giữ nguyên cấu trúc sub-folder trong folder xuất",
            variable=self.preserve_structure_var,
        ).grid(row=2, column=0, columnspan=2, sticky="w", padx=10, pady=4)
        ttk.Checkbutton(
            frame,
            text="Ghi đè file trùng tên",
            variable=self.overwrite_var,
        ).grid(row=3, column=0, columnspan=2, sticky="w", padx=10, pady=(4, 10))

    def build_background_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="3. Nền ảnh", style="Section.TLabelframe")
        frame.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        frame.columnconfigure(1, weight=1)

        ttk.Label(frame, text="Kiểu nền").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        self.bg_mode_combo = ttk.Combobox(
            frame,
            textvariable=self.background_label_var,
            values=list(BACKGROUND_LABELS.keys()),
            state="readonly",
            width=18,
        )
        self.bg_mode_combo.grid(row=0, column=1, sticky="ew", padx=10, pady=(10, 4))
        self.bg_mode_combo.bind("<<ComboboxSelected>>", lambda _event: self.refresh_background_controls())

        ttk.Label(frame, text="Màu nền").grid(row=1, column=0, sticky="w", padx=10, pady=4)
        color_row = ttk.Frame(frame)
        color_row.grid(row=1, column=1, sticky="ew", padx=10, pady=4)
        color_row.columnconfigure(0, weight=1)
        self.color_entry = ttk.Entry(color_row, textvariable=self.background_color_var)
        self.color_entry.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.color_button = ttk.Button(color_row, text="Chọn màu", command=self.choose_color)
        self.color_button.grid(row=0, column=1)

        ttk.Label(frame, text="Ảnh nền").grid(row=2, column=0, sticky="w", padx=10, pady=4)
        bg_row = ttk.Frame(frame)
        bg_row.grid(row=2, column=1, sticky="ew", padx=10, pady=4)
        bg_row.columnconfigure(0, weight=1)
        self.bg_image_label = ttk.Label(bg_row, textvariable=self.bg_image_summary_var, wraplength=250)
        self.bg_image_label.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.bg_image_button = ttk.Button(bg_row, text="Chọn ảnh", command=self.choose_background_image)
        self.bg_image_button.grid(row=0, column=1)

        ttk.Checkbutton(
            frame,
            text="Cắt viền trong suốt trước khi đặt vào khung",
            variable=self.trim_transparent_var,
        ).grid(row=3, column=0, columnspan=2, sticky="w", padx=10, pady=(4, 10))

    def build_canvas_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="4. Khung và kích thước", style="Section.TLabelframe")
        frame.grid(row=3, column=0, sticky="ew", pady=(0, 10))
        frame.columnconfigure(1, weight=1)

        ttk.Label(frame, text="Khung").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        preset_combo = ttk.Combobox(
            frame,
            textvariable=self.canvas_preset_var,
            values=CANVAS_PRESETS,
            state="readonly",
            width=18,
        )
        preset_combo.grid(row=0, column=1, sticky="ew", padx=10, pady=(10, 4))
        preset_combo.bind("<<ComboboxSelected>>", lambda _event: self.apply_canvas_preset())

        size_row = ttk.Frame(frame)
        size_row.grid(row=1, column=0, columnspan=2, sticky="ew", padx=10, pady=4)
        size_row.columnconfigure(1, weight=1)
        size_row.columnconfigure(3, weight=1)
        ttk.Label(size_row, text="Rộng").grid(row=0, column=0, sticky="w")
        ttk.Entry(size_row, textvariable=self.canvas_width_var, width=8).grid(
            row=0, column=1, sticky="ew", padx=(6, 12)
        )
        ttk.Label(size_row, text="Cao").grid(row=0, column=2, sticky="w")
        ttk.Entry(size_row, textvariable=self.canvas_height_var, width=8).grid(
            row=0, column=3, sticky="ew", padx=(6, 0)
        )

        ttk.Label(frame, text="Độ lớn ảnh").grid(row=2, column=0, sticky="w", padx=10, pady=4)
        scale_row = ttk.Frame(frame)
        scale_row.grid(row=2, column=1, sticky="ew", padx=10, pady=4)
        scale_row.columnconfigure(0, weight=1)
        scale = ttk.Scale(scale_row, from_=10, to=250, variable=self.scale_var, command=self.on_scale_change)
        scale.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        ttk.Label(scale_row, textvariable=self.scale_text_var, width=5).grid(row=0, column=1)

        offset_row = ttk.Frame(frame)
        offset_row.grid(row=3, column=0, columnspan=2, sticky="ew", padx=10, pady=(4, 10))
        offset_row.columnconfigure(1, weight=1)
        offset_row.columnconfigure(3, weight=1)
        ttk.Label(offset_row, text="Dịch ngang").grid(row=0, column=0, sticky="w")
        tk.Spinbox(offset_row, textvariable=self.offset_x_var, from_=-5000, to=5000, width=7).grid(
            row=0, column=1, sticky="ew", padx=(6, 12)
        )
        ttk.Label(offset_row, text="Dịch dọc").grid(row=0, column=2, sticky="w")
        tk.Spinbox(offset_row, textvariable=self.offset_y_var, from_=-5000, to=5000, width=7).grid(
            row=0, column=3, sticky="ew", padx=(6, 0)
        )

    def build_format_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="5. Xuất file", style="Section.TLabelframe")
        frame.grid(row=4, column=0, sticky="ew", pady=(0, 10))
        frame.columnconfigure(1, weight=1)

        ttk.Label(frame, text="Định dạng").grid(row=0, column=0, sticky="w", padx=10, pady=(10, 4))
        ttk.Combobox(
            frame,
            textvariable=self.output_format_var,
            values=OUTPUT_FORMATS,
            state="readonly",
            width=18,
        ).grid(row=0, column=1, sticky="ew", padx=10, pady=(10, 4))

        ttk.Label(frame, text="Chất lượng").grid(row=1, column=0, sticky="w", padx=10, pady=4)
        quality_row = ttk.Frame(frame)
        quality_row.grid(row=1, column=1, sticky="ew", padx=10, pady=4)
        quality_row.columnconfigure(0, weight=1)
        ttk.Scale(quality_row, from_=1, to=100, variable=self.quality_var, command=self.on_quality_change).grid(
            row=0, column=0, sticky="ew", padx=(0, 8)
        )
        ttk.Label(quality_row, textvariable=self.quality_text_var, width=4).grid(row=0, column=1)

        ttk.Label(frame, text="Chỉ định riêng").grid(row=2, column=0, sticky="w", padx=10, pady=4)
        csv_row = ttk.Frame(frame)
        csv_row.grid(row=2, column=1, sticky="ew", padx=10, pady=4)
        csv_row.columnconfigure(0, weight=1)
        ttk.Label(csv_row, textvariable=self.csv_summary_var, wraplength=260).grid(
            row=0, column=0, sticky="ew", padx=(0, 6)
        )
        ttk.Button(csv_row, text="Chọn CSV", command=self.choose_override_csv).grid(row=0, column=1)
        ttk.Button(frame, text="Bỏ CSV riêng", command=self.clear_override_csv).grid(
            row=3, column=1, sticky="e", padx=10, pady=(0, 10)
        )

    def build_action_section(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent)
        frame.grid(row=5, column=0, sticky="ew")
        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(1, weight=1)

        self.preview_button = ttk.Button(frame, text="Xem thử ảnh đầu tiên", command=self.preview_first_image)
        self.preview_button.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self.start_button = ttk.Button(
            frame,
            text="Bắt đầu xử lý",
            style="Accent.TButton",
            command=self.start_processing,
        )
        self.start_button.grid(row=0, column=1, sticky="ew", padx=(5, 0))

        self.progress_bar = ttk.Progressbar(frame, mode="determinate")
        self.progress_bar.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 4))
        ttk.Label(frame, textvariable=self.status_var).grid(row=2, column=0, columnspan=2, sticky="w")

    def build_preview_section(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="Xem trước", style="Title.TLabel").grid(row=0, column=0, sticky="w")
        preview_frame = ttk.Frame(parent, relief="solid", borderwidth=1)
        preview_frame.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        preview_frame.columnconfigure(0, weight=1)
        preview_frame.rowconfigure(0, weight=1)
        self.preview_label = ttk.Label(
            preview_frame,
            text="Chọn ảnh rồi bấm “Xem thử ảnh đầu tiên”.",
            anchor="center",
        )
        self.preview_label.grid(row=0, column=0, sticky="nsew", padx=12, pady=12)

    def build_log_section(self, parent: ttk.Frame) -> None:
        frame = ttk.LabelFrame(parent, text="Nhật ký xử lý", style="Section.TLabelframe")
        frame.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(14, 0))
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        self.log_text = tk.Text(frame, height=8, wrap="word", state="disabled")
        self.log_text.grid(row=0, column=0, sticky="nsew", padx=(10, 0), pady=10)
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns", padx=(0, 10), pady=10)
        self.log_text.configure(yscrollcommand=scrollbar.set)

    def choose_files(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Chọn ảnh",
            filetypes=[
                ("Image files", "*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff"),
                ("All files", "*.*"),
            ],
        )
        if not paths:
            return
        self.selected_files = [Path(path) for path in paths]
        self.selected_folder = None
        self.input_summary_var.set(f"Đã chọn {len(self.selected_files)} ảnh.")
        self.autofill_output_folder(self.selected_files[0].parent / "_output")

    def choose_input_folder(self) -> None:
        path = filedialog.askdirectory(title="Chọn folder ảnh đầu vào")
        if not path:
            return
        self.selected_folder = Path(path)
        self.selected_files = []
        self.input_summary_var.set(short_path(self.selected_folder))
        self.autofill_output_folder(self.selected_folder.parent / f"{self.selected_folder.name}_output")

    def clear_input(self) -> None:
        self.selected_files = []
        self.selected_folder = None
        self.input_summary_var.set("Chưa chọn nguồn ảnh")

    def choose_output_folder(self) -> None:
        path = filedialog.askdirectory(title="Chọn folder xuất ảnh")
        if not path:
            return
        self.output_folder = Path(path)
        self.output_summary_var.set(short_path(self.output_folder))

    def autofill_output_folder(self, candidate: Path) -> None:
        if self.output_folder:
            return
        self.output_folder = candidate
        self.output_summary_var.set(short_path(candidate))

    def choose_color(self) -> None:
        _rgb, hex_value = colorchooser.askcolor(color=self.background_color_var.get(), title="Chọn màu nền")
        if hex_value:
            self.background_color_var.set(hex_value)
            self.background_label_var.set("Màu tự chọn")
            self.refresh_background_controls()

    def choose_background_image(self) -> None:
        path = filedialog.askopenfilename(
            title="Chọn ảnh nền",
            filetypes=[
                ("Image files", "*.png *.jpg *.jpeg *.webp *.bmp *.tif *.tiff"),
                ("All files", "*.*"),
            ],
        )
        if not path:
            return
        self.background_image = Path(path)
        self.bg_image_summary_var.set(short_path(self.background_image, 44))
        self.background_label_var.set("Ảnh nền")
        self.refresh_background_controls()

    def choose_override_csv(self) -> None:
        path = filedialog.askopenfilename(
            title="Chọn file CSV chỉ định riêng",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        self.override_csv = Path(path)
        self.csv_summary_var.set(short_path(self.override_csv, 44))

    def clear_override_csv(self) -> None:
        self.override_csv = None
        self.csv_summary_var.set("Không dùng file CSV riêng")

    def refresh_background_controls(self) -> None:
        mode = BACKGROUND_LABELS.get(self.background_label_var.get(), "white")
        color_state = "normal" if mode == "color" else "disabled"
        image_state = "normal" if mode == "image" else "disabled"
        self.color_entry.configure(state=color_state)
        self.color_button.configure(state=color_state)
        self.bg_image_button.configure(state=image_state)

    def apply_canvas_preset(self) -> None:
        preset = self.canvas_preset_var.get()
        if preset == "Tự nhập":
            return
        width, height = parse_canvas_size(preset)
        self.canvas_width_var.set(str(width))
        self.canvas_height_var.set(str(height))

    def on_scale_change(self, _value: str) -> None:
        self.scale_text_var.set(f"{int(float(self.scale_var.get()))}%")

    def on_quality_change(self, _value: str) -> None:
        self.quality_text_var.set(str(int(float(self.quality_var.get()))))

    def read_settings(self) -> AppSettings:
        if not self.selected_files and not self.selected_folder:
            raise ValueError("Bạn chưa chọn ảnh hoặc folder đầu vào.")
        if not self.output_folder:
            raise ValueError("Bạn chưa chọn folder xuất ảnh.")

        width = int(self.canvas_width_var.get())
        height = int(self.canvas_height_var.get())
        if width <= 0 or height <= 0:
            raise ValueError("Kích thước khung phải lớn hơn 0.")

        bg_label = self.background_label_var.get()
        background_mode = BACKGROUND_LABELS.get(bg_label, "white")
        background_color = (
            color_to_hex(self.background_color_var.get()) if background_mode == "color" else "#ffffff"
        )
        if background_mode == "image" and not self.background_image:
            raise ValueError("Bạn đã chọn nền ảnh nhưng chưa chọn file ảnh nền.")

        output_format = self.output_format_var.get().upper()
        if output_format not in OUTPUT_FORMATS:
            raise ValueError("Định dạng xuất không hợp lệ.")

        return AppSettings(
            input_files=tuple(self.selected_files),
            input_folder=self.selected_folder,
            include_subfolders=self.include_subfolders_var.get(),
            output_folder=self.output_folder,
            preserve_structure=self.preserve_structure_var.get(),
            overwrite=self.overwrite_var.get(),
            output_format=output_format,
            quality=int(float(self.quality_var.get())),
            canvas_size=(width, height),
            background_mode=background_mode,
            background_color=background_color,
            background_image=self.background_image,
            product_scale=int(float(self.scale_var.get())),
            trim_transparent=self.trim_transparent_var.get(),
            offset_x=int(self.offset_x_var.get()),
            offset_y=int(self.offset_y_var.get()),
            override_csv=self.override_csv,
        )

    def preview_first_image(self) -> None:
        try:
            settings = self.read_settings()
            images, input_root = gather_input_images(settings)
            if not images:
                raise ValueError("Không tìm thấy ảnh để xem thử.")
            overrides = load_overrides(settings.override_csv)
            image_path = images[0]
            override = find_override(image_path, input_root, overrides)
            preview = compose_image(image_path, settings, override)
            preview.thumbnail((620, 620), Image.Resampling.LANCZOS)
            self.preview_photo = ImageTk.PhotoImage(preview)
            self.preview_label.configure(image=self.preview_photo, text="")
            self.status_var.set(f"Đang xem thử: {image_path.name}")
            self.append_log(f"[XEM THỬ] {image_path}")
        except Exception as exc:
            messagebox.showerror("Không xem thử được", str(exc))
            self.append_log(f"[LỖI XEM THỬ] {exc}")

    def start_processing(self) -> None:
        if self.worker_thread and self.worker_thread.is_alive():
            return

        try:
            settings = self.read_settings()
        except Exception as exc:
            messagebox.showerror("Thiếu thông tin", str(exc))
            return

        self.set_processing_state(True)
        self.clear_log()
        self.events.put(("log", "Bắt đầu xử lý..."))
        self.worker_thread = threading.Thread(target=self.worker, args=(settings,), daemon=True)
        self.worker_thread.start()

    def worker(self, settings: AppSettings) -> None:
        try:
            success_count, fail_count = process_images(
                settings,
                log=lambda message: self.events.put(("log", message)),
                progress=lambda current, total: self.events.put(("progress", (current, total))),
            )
            self.events.put(("done", (success_count, fail_count, "")))
        except Exception:
            self.events.put(("done", (0, 0, traceback.format_exc())))

    def poll_events(self) -> None:
        try:
            while True:
                event, payload = self.events.get_nowait()
                if event == "log":
                    self.append_log(str(payload))
                elif event == "progress":
                    current, total = payload  # type: ignore[misc]
                    self.update_progress(int(current), int(total))
                elif event == "done":
                    success_count, fail_count, error = payload  # type: ignore[misc]
                    self.finish_processing(int(success_count), int(fail_count), str(error))
        except queue.Empty:
            pass
        self.root.after(100, self.poll_events)

    def update_progress(self, current: int, total: int) -> None:
        self.progress_bar.configure(maximum=max(1, total), value=current)
        self.status_var.set(f"Đã xử lý {current}/{total} ảnh.")

    def finish_processing(self, success_count: int, fail_count: int, error: str) -> None:
        self.set_processing_state(False)
        if error:
            self.status_var.set("Có lỗi khi xử lý.")
            self.append_log(error)
            messagebox.showerror("Lỗi xử lý", "Có lỗi khi xử lý. Xem nhật ký để biết chi tiết.")
            return
        self.status_var.set(f"Hoàn tất: {success_count} ảnh thành công, {fail_count} lỗi.")
        self.append_log(f"Hoàn tất: {success_count} ảnh thành công, {fail_count} lỗi.")
        messagebox.showinfo("Hoàn tất", f"Đã xử lý xong.\nThành công: {success_count}\nLỗi: {fail_count}")

    def set_processing_state(self, is_processing: bool) -> None:
        state = "disabled" if is_processing else "normal"
        self.start_button.configure(state=state)
        self.preview_button.configure(state=state)

    def clear_log(self) -> None:
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def append_log(self, message: str) -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")


def main() -> None:
    root = tk.Tk()
    app = ImageBatchComposerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
